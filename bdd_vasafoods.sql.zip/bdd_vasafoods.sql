-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-11-2020 a las 06:23:28
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdd_vasafoods`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cochinita`
--

CREATE TABLE `cochinita` (
  `Id` bigint(20) UNSIGNED NOT NULL,
  `cantidad` varchar(5) NOT NULL,
  `patita` varchar(2) NOT NULL,
  `RFC` varchar(13) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `municipio` varchar(25) NOT NULL,
  `calle` varchar(50) NOT NULL,
  `colonia` varchar(50) NOT NULL,
  `numExterior` varchar(10) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cochinita`
--

INSERT INTO `cochinita` (`Id`, `cantidad`, `patita`, `RFC`, `nombre`, `municipio`, `calle`, `colonia`, `numExterior`, `tel`, `fecha`) VALUES
(1, '500 g', 'si', '1014545879', 'JORGE LUIS ', 'toluca', 'Vicente Villada', 'Las flores', '6', '7228745216', '2020-10-01'),
(2, '1kg', 'no', '2356475812', 'ZAID ', 'Toluca', 'Independencia de mayo', 'Col Independencia', '8', '7296581458', '2020-09-22'),
(20, '15Kg', 'Si', 'BOCA980810', 'pedro', 'toluca', 'lerdo', 'las fuentes', '1123', '7521654351', '2020-11-21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consulta`
--

CREATE TABLE `consulta` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `asunto` varchar(30) NOT NULL,
  `mensaje` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `consulta`
--

INSERT INTO `consulta` (`id`, `nombre`, `email`, `asunto`, `mensaje`) VALUES
(3, 'Jorge Becerril ', 'jorge@gmail.com', 'Pedido no entregado', 'El dia de ayer solicite un pedido para el dia de hoy y nunca llego me gustaria saber el motivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `donas`
--

CREATE TABLE `donas` (
  `Id` bigint(20) UNSIGNED NOT NULL,
  `cantidad` tinyint(1) NOT NULL,
  `sabor` varchar(15) NOT NULL,
  `RFC` int(13) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `municipio` varchar(25) NOT NULL,
  `calle` varchar(50) NOT NULL,
  `colonia` varchar(50) NOT NULL,
  `numExterior` varchar(10) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `donas`
--

INSERT INTO `donas` (`Id`, `cantidad`, `sabor`, `RFC`, `nombre`, `municipio`, `calle`, `colonia`, `numExterior`, `tel`, `fecha`) VALUES
(5, 10, 'Surtido', 1236541236, 'ARMANDO ', 'Toluca', 'Escutia Moron', 'Las tlacopas', '0', '7296587412', '2020-11-09'),
(9, 5, 'Chocolate', 1545623215, 'FERNANDO', 'Toluca', '9 Julio San Juan Urquiza ', 'Col Independencia', '16', '7225698745', '2020-07-08'),
(13, 10, 'Azucar', 0, 'Angel', 'Toluca', 'bravo norte', 'Union', '400', '7232135481', '2020-11-13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ensalada`
--

CREATE TABLE `ensalada` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ensalada` varchar(30) NOT NULL,
  `RFC` varchar(13) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `municipio` varchar(25) NOT NULL,
  `calle` varchar(50) NOT NULL,
  `colonia` varchar(50) NOT NULL,
  `numExterior` varchar(10) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `fecha` date NOT NULL,
  `comentarios` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ensalada`
--

INSERT INTO `ensalada` (`id`, `ensalada`, `RFC`, `nombre`, `municipio`, `calle`, `colonia`, `numExterior`, `tel`, `fecha`, `comentarios`) VALUES
(2, 'Pasta', 'BEGO030705', 'Jorge', 'Toluca', 'calzada de san luis obispo', 'union', '412', '7229109049', '2020-11-12', 'Los aderezos aparte ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `RFC` varchar(15) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `contra` varchar(20) NOT NULL,
  `concontra` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`id`, `RFC`, `correo`, `nombre`, `tel`, `contra`, `concontra`) VALUES
(5, 'CAMA030807', 'casmas@gmail.com', 'Zaid Castro', '7229109049', 'cas123', 'cas123'),
(7, 'BEGO030507', 'BECERRIL@GMAIL.COM', 'JORGE BECERRIL', '7222351575', 'jorge123', 'jorge123'),
(8, 'BEGO030507', 'angel@gmail.com', 'Angel Gonzalez', '7222315482', '1234', '1234');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cochinita`
--
ALTER TABLE `cochinita`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Id` (`Id`);

--
-- Indices de la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `donas`
--
ALTER TABLE `donas`
  ADD UNIQUE KEY `Id` (`Id`);

--
-- Indices de la tabla `ensalada`
--
ALTER TABLE `ensalada`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cochinita`
--
ALTER TABLE `cochinita`
  MODIFY `Id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `consulta`
--
ALTER TABLE `consulta`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `donas`
--
ALTER TABLE `donas`
  MODIFY `Id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `ensalada`
--
ALTER TABLE `ensalada`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `registro`
--
ALTER TABLE `registro`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
